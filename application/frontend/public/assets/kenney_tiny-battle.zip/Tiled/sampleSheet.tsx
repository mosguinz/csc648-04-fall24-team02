<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Tilemap" tilewidth="16" tileheight="16" spacing="1" tilecount="198" columns="18">
 <image source="../Tilemap/tilemap.png" trans="feae34" width="305" height="186"/>
</tileset>
